class Player {
  constructor(squareState, name) {
    this.squareState = squareState;
    this.name = name;
  }
}

